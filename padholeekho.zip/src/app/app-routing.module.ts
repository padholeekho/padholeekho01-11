import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HeaderComponent, NavComponent} from './shared';
import { moduleRoutes } from './shared';
import { AuthGuard } from './core';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  }, 
  {
    path: 'home',
    component: HeaderComponent,
    loadChildren: './modules/home/home.module#HomeModule'
  },
  {
    path: 'home-user-profile',
    component: NavComponent,
    canActivate: [AuthGuard],
    loadChildren: './modules/home/home.module#HomeModule'
  }, 
  { 
    path: '',   
    component: HeaderComponent,
    children: moduleRoutes
  },
  { path: '**', redirectTo: 'home', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
