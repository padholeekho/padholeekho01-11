import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CompettitiveRoutingModule } from './compettitive-routing.module';
import { CatComponent } from './pages/cat/cat.component';

@NgModule({
  declarations: [CatComponent],
  imports: [
    CommonModule,
    CompettitiveRoutingModule
  ]
})
export class CompetitiveModule { }
