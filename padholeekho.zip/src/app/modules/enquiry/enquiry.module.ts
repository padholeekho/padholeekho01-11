import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EnquiryComponent } from './pages/enquiry/enquiry.component';
import { EnquiryRoutingModule } from './enquiry-routing.module';
import { SharedModule } from '../../shared/shared.module';
import { ReactiveFormsModule } from '@angular/forms'

@NgModule({
  declarations: [EnquiryComponent],
  imports: [
    CommonModule,
    EnquiryRoutingModule,
    SharedModule,
    ReactiveFormsModule,
  ]
})

export class EnquiryModule { }
