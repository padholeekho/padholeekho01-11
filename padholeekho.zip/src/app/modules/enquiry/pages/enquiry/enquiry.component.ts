import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-enquiry',
  templateUrl: './enquiry.component.html',
  styleUrls: ['./enquiry.component.css']
})
export class EnquiryComponent implements OnInit {
  enquiryForm : FormGroup;
  submitted: boolean = false;

  constructor ( private formBuilder: FormBuilder ) { 
    this.enquiryForm = this.formBuilder.group({
      name: ["", Validators.required ],
      email: ["", [Validators.required, Validators.email]],
      super_course_id: ["", Validators.required ],
      phone: [null, [Validators.required,Validators.pattern('^((\\+91-?)|0)?[0-9]{10}$')]],
      enquiry: ["", Validators.required ],
      via_phone: [""],
    })
   }

   get f() {
    return this.enquiryForm.controls;
  }

  ngOnInit() {

  }

  enquiry(){
   this.submitted = true;
   if (this.enquiryForm.invalid) {
    return;
  }
   console.log(this.enquiryForm.value)
  }
  
}
