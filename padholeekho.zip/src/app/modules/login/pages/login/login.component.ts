import { Component, OnInit } from '@angular/core';
import { LoginService } from '../../services';
import { tap, map, finalize, catchError, } from 'rxjs/operators';
import { of, throwError, from } from 'rxjs';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  submitted: boolean = false;
  isLoading: boolean;
  error: any;

  constructor(
    private loginService: LoginService,
    private formBuilder: FormBuilder,
    private router: Router
  ) {
    this.loginForm = this.formBuilder.group({
      emailphone: ["", [Validators.required, Validators.email]],
      password: ["", [Validators.required, Validators.minLength(6)]]
    })
  }

  get f() { 
    return this.loginForm.controls; 
  }

  ngOnInit() { }

  login() {
    this.submitted = true;
    if (this.loginForm.invalid) {
      return;
    }
    this.loginService.loginApi(this.loginForm.value).pipe(
      tap(response => {
        console.log(response)
        if (response.status == "success") {
          this.router.navigate(['home-user-profile']);
        }
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = error))
    ).subscribe();
  }

  goRegister() {
    this.router.navigate(['register']);
  }

}
