import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.css']
})
export class UpdateProfileComponent implements OnInit {
  profileupdateForm: FormGroup;
  submitted: boolean = false;
  isLoading: boolean = false;
  message: any;

  constructor(private formBuilder: FormBuilder) {
    this.profileupdateForm = this.formBuilder.group({
      name: ["", [Validators.required]],
      email: ["", [Validators.required, Validators.email]],
    }) 
  }

  get f() {
    return this.profileupdateForm.controls;
  }

  updateprofile(){
    this.submitted = true;
    if (this.profileupdateForm.invalid) {
      return;
    }
  }

  goLogin(){
    console.log('Hi');
  }


  ngOnInit() {
  }

}
