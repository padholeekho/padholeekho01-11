import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-support',
  templateUrl: './support.component.html',
  styleUrls: ['./support.component.css']
})
export class SupportComponent implements OnInit {

  supportForm : FormGroup;
  submitted: boolean = false;

  constructor(
    private formBuilder: FormBuilder,

  ) {
    this.supportForm = this.formBuilder.group({
      name: ["", Validators.required ],
      email: ["", [Validators.required, Validators.email]],
      super_course_id: ["", Validators.required ],
      phone: [null, [Validators.required,Validators.pattern('^((\\+91-?)|0)?[0-9]{10}$')]],
      support: ["", Validators.required ],
      via_phone: [""],
    })
   }

  get f() {
    return this.supportForm.controls;
  }

  ngOnInit() {
  }

  support(){
    this.submitted = true;
    if (this.supportForm.invalid) {
      return;
    }
    console.log(this.supportForm.value);
  }

}
