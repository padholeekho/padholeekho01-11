import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TestimonialComponent, DownloadComponent } from '../shared'; 

@NgModule({
  declarations: [TestimonialComponent, DownloadComponent],
  imports: [
    CommonModule
  ],
  exports: [TestimonialComponent, DownloadComponent]
})
export class SharedModule { }
