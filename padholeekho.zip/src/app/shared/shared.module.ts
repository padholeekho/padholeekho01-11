import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TestimonialComponent, DownloadComponent } from '../shared';
import { IsloadingComponent } from './isloading/isloading.component';

@NgModule({
  declarations: [TestimonialComponent, DownloadComponent, IsloadingComponent],
  imports: [
    CommonModule
  ],
  exports: [TestimonialComponent, DownloadComponent, IsloadingComponent]
})
export class SharedModule { }
